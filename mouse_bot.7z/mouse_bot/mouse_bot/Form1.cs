﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace mouse_bot
{
    public partial class Form1 : Form
    {
        public const uint ES_CONTINUOUS = 0x80000000;
        public const uint ES_SYSTEM_REQUIRED = 0x00000001;
        public const uint ES_DISPLAY_REQUIRED = 0x00000002;

        public const byte VK_BACK = 0x08;
        public const uint KEYEVENTF_KEYUP = 0x0002;
        public const uint KEYEVENTF_KEYDOWN = 0x0000;
        public const byte VK_LWIN = 0x5B;

        public const byte VK_0 = 0x30;
        public const byte VK_1 = 0x31;
        public const byte VK_2 = 0x32;
        public const byte VK_3 = 0x33;
        public const byte VK_4 = 0x34;
        public const byte VK_5 = 0x35;
        public const byte VK_6 = 0x36;
        public const byte VK_7 = 0x37;
        public const byte VK_8 = 0x38;
        public const byte VK_9 = 0x39;

        [Flags]
        public enum MouseEventFlags
        {
            LeftDown = 0x00000002,
            LeftUp = 0x00000004,
            MiddleDown = 0x00000020,
            MiddleUp = 0x00000040,
            Move = 0x00000001,
            Absolute = 0x00008000,
            RightDown = 0x00000008,
            RightUp = 0x00000010
        }

        /*
         * 1 test avec couple de départ réglable
         * Palier par couple réglable (2mn défaut)
         * Départ et arrêt du test manuel
        */

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern uint SetThreadExecutionState([In] uint esFlags);

        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        [DllImport("user32.dll", EntryPoint = "SetCursorPos")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetCursorPos(int x, int y);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetCursorPos(out MousePoint lpMousePoint);

        [DllImport("user32.dll")]
        private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

        [StructLayout(LayoutKind.Sequential)]
        public struct MousePoint
        {
            public int X;
            public int Y;

            public MousePoint(int x, int y)
            {
                X = x;
                Y = y;
            }
        }

        public static void MouseEvent(MouseEventFlags value)
        {
            MousePoint position = GetCursorPosition();

            mouse_event
                ((int)value,
                 position.X,
                 position.Y,
                 0,
                 0)
                ;
        }

        public static MousePoint GetCursorPosition()
        {
            MousePoint currentMousePoint;
            var gotPoint = GetCursorPos(out currentMousePoint);
            if (!gotPoint) { currentMousePoint = new MousePoint(0, 0); }
            return currentMousePoint;
        }

        public static void SetCursorPosition(int x, int y)
        {
            SetCursorPos(x, y);
        }

        public static void SetCursorPosition(MousePoint point)
        {
            SetCursorPos(point.X, point.Y);
        }

        DateTime start_date;
        DateTime current_date;
        int torque_nb = 0;
        int valid_torque_nb = 0;
        int final_torque_nb = 0;
        string[] torques = new string[31];
        int individual_test_duration = 1;
        int current_torque_index = 0;

        public Form1()
        {
            InitializeComponent();
            torque_nb = trackBar2.Value - trackBar1.Value + 1;
            label7.Text = trackBar1.Value.ToString() + " Nm";
            label8.Text = trackBar2.Value.ToString() + " Nm";
            label9.Text = trackBar3.Value.ToString() + " mn";
            label11.Text = "Temps estimé : " + (trackBar3.Value * torque_nb * 1.33).ToString() + " mn";

            button_start.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            double elapsed = 0;
            current_date = DateTime.Now;
            
            SetThreadExecutionState(ES_CONTINUOUS | ES_DISPLAY_REQUIRED | ES_SYSTEM_REQUIRED);
            string difference_date = "Temps écoulé : " + (current_date - start_date).Hours + "h" + (current_date - start_date).Minutes + "m" + (current_date - start_date).Seconds + "s";
            label1.Text = difference_date;
            elapsed = ((current_date - start_date).Seconds + (current_date - start_date).Minutes * 60 + (current_date - start_date).Hours * 3600) * 100 / (trackBar3.Value * 1.33 * torque_nb * 60);
            progressBar3.Value = Math.Max(0, Math.Min((int)elapsed, 100));
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            start_date = DateTime.Now;

            if (timer1.Enabled == false)
            {
                timer1.Enabled = true;
                button_start.Text = "Rétablir veille";
            }
            else
            {
                timer1.Enabled = false;
                button_start.Text = "Empêcher veille";
            }

            backgroundWorker1.RunWorkerAsync();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //1380:280
            SetCursorPosition(1380, 280);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //1380:645
            SetCursorPosition(1380, 645);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //1380:585
            SetCursorPosition(1035, 585);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //1335:500
            SetCursorPosition(1380, 500);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //1380:215
            SetCursorPosition(1380, 215);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string value = textBox1.Text;
            byte[] key = new byte[10];
            int torque;
            MousePoint currentMousePoint;

            currentMousePoint = GetCursorPosition();

            SetCursorPosition(currentMousePoint.X-100, currentMousePoint.Y+20);

            MouseEvent(MouseEventFlags.LeftDown);
            MouseEvent(MouseEventFlags.LeftUp);

            keybd_event(VK_BACK, 0, 0, (UIntPtr)0);
            keybd_event(VK_BACK, 0, KEYEVENTF_KEYUP, (UIntPtr)0);
            keybd_event(VK_BACK, 0, 0, (UIntPtr)0);
            keybd_event(VK_BACK, 0, KEYEVENTF_KEYUP, (UIntPtr)0);
            keybd_event(VK_BACK, 0, 0, (UIntPtr)0);
            keybd_event(VK_BACK, 0, KEYEVENTF_KEYUP, (UIntPtr)0);

            System.Threading.Thread.Sleep(200);

            for (int i = 0; i < value.Length; i++)
            {
                torque = Int16.Parse(value.Substring(i,1));
                torque += 0x60;
               
                keybd_event((byte)torque, 0, 0, (UIntPtr)0);
                keybd_event((byte)torque, 0, KEYEVENTF_KEYUP, (UIntPtr)0);

                /*keybd_event(VK_0, 0, 0, (UIntPtr)0);
                keybd_event(VK_0, 0, KEYEVENTF_KEYUP, (UIntPtr)0);*/
            }
            SetCursorPosition(currentMousePoint);
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            string value;
            byte[] key = new byte[10];
            int torque;
            MousePoint currentMousePoint;
            int progress;
            current_torque_index = 0;
            final_torque_nb = torque_nb;

            Console.WriteLine("Nombre de couples : " + torque_nb.ToString());

            while (final_torque_nb != 0)
            {
                progress = 0;
                backgroundWorker1.ReportProgress(progress);

                Console.WriteLine("Mouse start");
                
                //Clic arrêt
                SetCursorPosition(1380, 280);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftDown);
                MouseEvent(MouseEventFlags.LeftUp);

                //Attente 10sec
                for (int i = 0; i < 10; i++)
                {
                    System.Threading.Thread.Sleep(1000); //Attente 1000msec
                    progress += 5;
                    backgroundWorker1.ReportProgress(progress);
                }

                //Clic enregistrer
                SetCursorPosition(1380, 645);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftDown);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftUp);

                //Attente 10sec
                for (int i = 0; i < 10; i++)
                {
                    System.Threading.Thread.Sleep(1000); //Attente 1000msec
                    progress += 5;
                    backgroundWorker1.ReportProgress(progress);
                }

                //Clic zone édition
                SetCursorPosition(1035, 585);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftDown);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftUp);
                System.Threading.Thread.Sleep(200); //Attente 200msec

                //Efface 3 caractères
                keybd_event(VK_BACK, 0, 0, (UIntPtr)0);
                keybd_event(VK_BACK, 0, KEYEVENTF_KEYUP, (UIntPtr)0);
                keybd_event(VK_BACK, 0, 0, (UIntPtr)0);
                keybd_event(VK_BACK, 0, KEYEVENTF_KEYUP, (UIntPtr)0);
                keybd_event(VK_BACK, 0, 0, (UIntPtr)0);
                keybd_event(VK_BACK, 0, KEYEVENTF_KEYUP, (UIntPtr)0);

                //Entre nouveau couple
                value = torques[current_torque_index++];
                for (int i = 0; i < value.Length; i++)
                {
                    torque = Int16.Parse(value.Substring(i, 1));
                    torque += 0x60;

                    keybd_event((byte)torque, 0, 0, (UIntPtr)0);
                    keybd_event((byte)torque, 0, KEYEVENTF_KEYUP, (UIntPtr)0);
                }

                //Sortie mode édition
                SetCursorPosition(1380, 500);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftDown);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftUp);

                //Démarrage nouveau test
                SetCursorPosition(1380, 215);
                System.Threading.Thread.Sleep(1000); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftDown);
                System.Threading.Thread.Sleep(100); //Attente 100msec
                MouseEvent(MouseEventFlags.LeftUp);

                //SetCursorPosition(currentMousePoint);

                System.Threading.Thread.Sleep(individual_test_duration * 1000 * 60); //Attente 1000msec
 
                final_torque_nb--;
            }      
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage < 50)
            {
                progressBar1.Value = e.ProgressPercentage*2;
            }
            else
            {
                progressBar1.Value = 100;
                progressBar2.Value = (e.ProgressPercentage-50)*2;
            }

            if(e.ProgressPercentage == 100)
            {
                progressBar1.Value = 0;
                progressBar2.Value = 0;   
            }

            if(e.ProgressPercentage == 0)
            {
                label12.Text = "Test "+ (current_torque_index+1).ToString() +"/" + torque_nb.ToString();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button7.Enabled = false;
            trackBar1.Enabled = false;
            trackBar2.Enabled = false;
            trackBar3.Enabled = false;


            for (int i = 0; i < torque_nb; i++) {
                torques[i] = (trackBar1.Value + i).ToString();
                Console.WriteLine(torques[i]);
            }

            start_date = DateTime.Now;
            timer1.Enabled = true;

            backgroundWorker1.RunWorkerAsync();

        }

        private void check_couples()
        {
            /*torque_nb = 0;
            valid_torque_nb = 0;
            int torque_exist = 20;

            if (textBox_torque_1.Text != "")
            {
                torque_nb++;
                torque_exist = 0;
                if (textBox_torque_1.Text.All(Char.IsDigit) && textBox_torque_1.Text.Length <= 3)
                {
                    torques[valid_torque_nb] = textBox_torque_1.Text;
                    valid_torque_nb++;
                    textBox_torque_1.BackColor = System.Drawing.Color.LightGreen;
                }
                else textBox_torque_1.BackColor = System.Drawing.Color.LightCoral;
            }
            else textBox_torque_1.BackColor = System.Drawing.SystemColors.Window;

            if (textBox_torque_2.Text != "")
            {
                torque_nb++;
                torque_exist = 0;
                if (textBox_torque_2.Text.All(Char.IsDigit) && textBox_torque_2.Text.Length <= 3)
                {
                    torques[valid_torque_nb] = textBox_torque_2.Text;
                    valid_torque_nb++;
                    textBox_torque_2.BackColor = System.Drawing.Color.LightGreen;
                }
                else textBox_torque_2.BackColor = System.Drawing.Color.LightCoral;
            }
            else textBox_torque_2.BackColor = System.Drawing.SystemColors.Window;

            if (textBox_torque_3.Text != "")
            {
                torque_nb++;
                torque_exist = 0;
                if (textBox_torque_3.Text.All(Char.IsDigit) && textBox_torque_3.Text.Length <= 3)
                {
                    torques[valid_torque_nb] = textBox_torque_3.Text;
                    valid_torque_nb++;
                    textBox_torque_3.BackColor = System.Drawing.Color.LightGreen;
                }
                else textBox_torque_3.BackColor = System.Drawing.Color.LightCoral;
            }
            else textBox_torque_3.BackColor = System.Drawing.SystemColors.Window;

            if (textBox_torque_4.Text != "")
            {
                torque_nb++;
                torque_exist = 0;
                if (textBox_torque_4.Text.All(Char.IsDigit) && textBox_torque_4.Text.Length <= 3)
                {
                    torques[valid_torque_nb] = textBox_torque_4.Text;
                    valid_torque_nb++;
                    textBox_torque_4.BackColor = System.Drawing.Color.LightGreen;
                }
                else textBox_torque_4.BackColor = System.Drawing.Color.LightCoral;
            }
            else textBox_torque_4.BackColor = System.Drawing.SystemColors.Window;

            if (textBox_torque_5.Text != "")
            {
                torque_nb++;
                torque_exist = 0;
                if (textBox_torque_5.Text.All(Char.IsDigit) && textBox_torque_5.Text.Length <= 3)
                {
                    torques[valid_torque_nb] = textBox_torque_5.Text;
                    valid_torque_nb++;
                    textBox_torque_5.BackColor = System.Drawing.Color.LightGreen;
                }
                else textBox_torque_5.BackColor = System.Drawing.Color.LightCoral;
            }
            else textBox_torque_5.BackColor = System.Drawing.SystemColors.Window;
            Console.WriteLine("Nombre de couples : " + torque_nb.ToString());
            Console.WriteLine("Nb de couples valid : " + valid_torque_nb.ToString());
            Console.WriteLine("Torque Exist : " + torque_exist.ToString());
            

            if (torque_nb - valid_torque_nb == 0 & torque_exist == 0)
            {
                final_torque_nb = valid_torque_nb;
                Console.WriteLine("Final valid torque : " + final_torque_nb.ToString());
                for (int i = 0; i < final_torque_nb; i++)
                {
                    Console.WriteLine("Torque " + i.ToString() + " : " + torques[i]);
                }

            }
            
            return torque_nb - valid_torque_nb + torque_exist;*/
        }

        private void button8_Click(object sender, EventArgs e)
        {
            
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            timer1.Enabled = false;
            button7.Enabled = true;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            trackBar2.Minimum = trackBar1.Value;
            torque_nb = trackBar2.Value - trackBar1.Value + 1;
            label7.Text = trackBar1.Value.ToString() + " Nm";
            label8.Text = trackBar2.Value.ToString() + " Nm";
            label10.Text = (trackBar2.Value - trackBar1.Value +1).ToString() + " test(s)";
            label11.Text = "Temps estimé : " + (trackBar3.Value * torque_nb).ToString() + " mn";
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            label7.Text = trackBar1.Value.ToString() + " Nm";
            label8.Text = trackBar2.Value.ToString() + " Nm";
            torque_nb = trackBar2.Value - trackBar1.Value + 1;
            label10.Text = (trackBar2.Value - trackBar1.Value + 1).ToString() + " test(s)";
            label11.Text = "Temps estimé : " + (trackBar3.Value * torque_nb * 1.33).ToString() + " mn";
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            individual_test_duration = trackBar3.Value;
            label9.Text = trackBar3.Value.ToString() + " mn";
            label11.Text = "Temps estimé : " + (trackBar3.Value * torque_nb * 1.33).ToString() + " mn";
        }
    }
}
